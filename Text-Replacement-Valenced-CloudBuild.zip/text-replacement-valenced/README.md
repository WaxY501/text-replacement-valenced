# Text Replacement for Valenced — source v0.3.0

Android Valenced plugin source. Shortcuts expand **when a message is sent**, not while typing.

## Features implemented in source
- Send-time interception through Valenced's public module finder and patcher API.
- Runtime lookup for the Discord module exposing `sendMessage` and `receiveMessage`.
- Hook teardown registered through plugin cleanup.
- Settings: enable/disable, add/edit/delete shortcuts.
- Pasted imports: JSON and Gboard tab dictionary / CSV variants.
- Incoming import entries override existing entries with the same trigger.
- Whole-token matching with punctuation boundaries; replacement text may include mentions, spaces and punctuation.

## Tests

Run:

```sh
node --test tests/core.test.mjs
```

The tests cover the pure parsing, merge, and expansion helpers. They do not live-test the Discord message hook or settings screen.


## Official Valenced build/package process

Valenced's current documented process uses the official `@valenced/plugin-cli` tool (Rolldown) to compile `js/index.tsx` to the bundle, then the plugin-template Gradle packaging task to produce the installable ZIP. The entrypoint must export a default plugin expression and API imports must be rewritten against the official import map.


## Build status in this environment

A real installable ZIP has **not** been produced. This environment currently has Node 22.16.0 (Valenced's CLI docs require Bun or Node 22.18+), no Bun installed, and network/DNS access to GitHub is unavailable. The official CLI, `@valenced/types` import map, and template packaging files could not be fetched. I won't create a fake ZIP with unresolved imports and call it installable.


## Remaining verification
- Build using the official Valenced CLI/import map and packaging toolchain.
- Verify the compiled ZIP structure and manifest with Valenced validation.
- Test on a live Android Valenced client: confirm send hook matcher, shortcut expansion, mentions, settings rendering, storage and imports.
- File picker support is not implemented; imports currently use pasted text.

## Reference pattern
The send hook approach is based on the sendMessage/receiveMessage finder signature used by the Revenge TextReplace reference, but the plugin uses Valenced APIs and does not import Revenge runtime code. The exact module signature is not yet live-verified against the user's client build.

## Cloud build (GitHub Actions)

The repo includes `.github/workflows/build-plugin.yml`. After uploading this folder to a GitHub repo, open **Actions → Build Text Replacement Plugin → Run workflow** (or push to `main`/`master`). The workflow installs Bun and the official Valenced CLI, runs the 7 helper tests, bundles the plugin, packages `manifest.json` + `index.js` into `Text-Replacement-Valenced.zip`, validates ZIP integrity, and uploads it as an Actions artifact. Download the artifact from the successful run; it is the sideload ZIP.

This cloud workflow has been added and locally checked for its file structure, but it has **not been executed from GitHub in this environment**. The first remote run is still required to verify that the current CLI import map accepts this plugin's imports and that the produced ZIP installs in Valenced.

**Upload to GitHub:** create a new repository, upload these project files (including `.github/workflows/build-plugin.yml`), then run the workflow from the Actions tab.
